/*
Dafne Linette Badillo Campuzano A01275298
Andrea Munoz Gris A01733058
*/

#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <ctype.h> 
#include <stdlib.h> 

#define SIZE 1024
  
struct node { 
    char data; 
    struct node *left, *right; 
}; 

struct Stack { 
    int top; 
    unsigned capacity; 
    int* array; 
}; 

struct Stack* createStack( unsigned capacity ) 
{ 
    struct Stack* stack = (struct Stack*) malloc(sizeof(struct Stack)); 
  
    if (!stack) return NULL; 
  
    stack->top = -1; 
    stack->capacity = capacity; 
    stack->array = (int*) malloc(stack->capacity * sizeof(int)); 
  
    if (!stack->array) return NULL; 
  
    return stack; 
} 
  
int isEmpty(struct Stack* stack) 
{ 
    return stack->top == -1 ; 
} 
  
char peek(struct Stack* stack) 
{ 
    return stack->array[stack->top]; 
} 
  
char pop(struct Stack* stack) 
{ 
    if (!isEmpty(stack)) 
        return stack->array[stack->top--] ; 
    return '$'; 
} 
  
void push(struct Stack* stack, char op) 
{ 
    stack->array[++stack->top] = op; 
} 
  
//PREFIX
char* add(struct node** p, char* a){ 
  
    if (*a == '\0') 
        return NULL; 
  
    while (1) { 
        char* q = "null"; 
        if (*p == NULL) { 
            struct node* nn = (struct node*)malloc(sizeof(struct node)); 
            nn->data = *a; 
            nn->left = NULL; 
            nn->right = NULL; 
            *p = nn; 
        } 
        else { 
            if (*a >= '0' && *a <= '9') { 
                return a; 
            } 
            q = add(&(*p)->left, a + 1); 
            q = add(&(*p)->right, q + 1); 
  
            return q; 
        }
    } 

}

//INFIX
char* add1(struct node** p, char* a){ 
  
    struct Stack* stack = createStack(strlen(a)); 
    int i; 
    for (i = 0; a[i]; ++i) 
    { 
        if (isdigit(a[i])) 
            push(stack, a[i] - '0'); 
        else
        { 
            int val1 = pop(stack); 
            int val2 = pop(stack); 
            switch (a[i]) 
            { 
            case '+': push(stack, val2 + val1); break; 
            case '-': push(stack, val2 - val1); break; 
            case '*': push(stack, val2 * val1); break; 
            case '/': push(stack, val2/val1); break; 
            } 
        } 
    } 
    return pop(stack); 

}

//POSTFIX
/*char* add2(struct node** p, char* a){

}*/
  
void inr(struct node* p) 
{ 
    if (p == NULL) { 
        return; 
    } 
    else { 
        inr(p->left); 
        printf("%c ", p->data); 
        inr(p->right); 
    } 
} 
void postr(struct node* p) 
{ 
    if (p == NULL) { 
        return; 
    } 
    else { 
        postr(p->left); 
        postr(p->right); 
        printf("%c ", p->data); 
    } 
} 

void prer(struct node* p){
        if(p==NULL){
                return;
        }
        else{
                printf("%c ", p->data);
                prer(p->left);
                prer(p->right);
        }
}

int operation(int x, int y, char z){
  int result = 0;
  switch(z){
    case '(':
      result = result;
      break;
    case ')':
      result = result;
      break;
    case '+':
      result = x + y;
      break;
    case '-':
      result = x - y;
      break;
    case '*':
      result = x * y;
      break;
    case '/':
      result = x / y;
      break;
    default:
      break;
  }
  return result;
}

int solution(struct node* p){
        char a = *(&p->data);
        int l, r, n;
        if(p==NULL){
                return 0;
        }
        if(p->left == NULL && p->right == NULL){
                scanf(&p->data, "%d");
                return n;
        }

        l = solution(p->left);
        r = solution(p->right);
        return operation(l, r, a);
}

int main() {
        int values;
        struct node* s = NULL; 
        char a[] = "SIZE";
        scanf("%i", &values);
        for (int i = 0; i < values; ++i){
                scanf("%s", a);

                if(*a >= '0' && *a <= '9'){
                   //add2(&s, a);
                    printf("The Prefix expression is:\n");
                    prer(s);
                    printf("\n"); 
                    printf("The Infix expression is:\n "); 
                    inr(s); 
                    printf("\n"); 
                    printf("The Postfix expression is:\n "); 
                    postr(s); 
                    printf("\n");
                    printf("Result:%d\n", solution(s));
                } else if(*a == '('){
                    add1(&s, a);
                    printf("The Prefix expression is:\n");
                    prer(s);
                    printf("\n"); 
                    printf("The Infix expression is:\n "); 
                    inr(s); 
                    printf("\n"); 
                    printf("The Postfix expression is:\n "); 
                    postr(s); 
                    printf("\n");
                    printf("Result:%d\n", solution(s));
                }else{
                    add(&s, a);
                    printf("The Prefix expression is:\n");
                    prer(s);
                    printf("\n"); 
                    printf("The Infix expression is:\n "); 
                    inr(s); 
                    printf("\n"); 
                    printf("The Postfix expression is:\n "); 
                    postr(s); 
                    printf("\n");
                    printf("Result:%d\n", solution(s));
                }
        }
        return 0; 
}